﻿namespace Wood_Workshop_Management
{
    partial class Frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_WeekDay = new System.Windows.Forms.Label();
            this.lbl_Time = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_Report = new System.Windows.Forms.Button();
            this.btn_Settings = new System.Windows.Forms.Button();
            this.btn_Help = new System.Windows.Forms.Button();
            this.btn_Manage = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Tan;
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 97);
            this.panel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.5F));
            this.tableLayoutPanel2.Controls.Add(this.lbl_WeekDay, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_Time, 1, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.38095F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.61905F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(800, 97);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // lbl_WeekDay
            // 
            this.lbl_WeekDay.AutoSize = true;
            this.lbl_WeekDay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_WeekDay.Font = new System.Drawing.Font("A Iranian Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl_WeekDay.Location = new System.Drawing.Point(323, 29);
            this.lbl_WeekDay.Name = "lbl_WeekDay";
            this.lbl_WeekDay.Size = new System.Drawing.Size(150, 27);
            this.lbl_WeekDay.TabIndex = 2;
            this.lbl_WeekDay.Text = "label1";
            // 
            // lbl_Time
            // 
            this.lbl_Time.AutoSize = true;
            this.lbl_Time.Font = new System.Drawing.Font("A Iranian Sans", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl_Time.Location = new System.Drawing.Point(340, 56);
            this.lbl_Time.Margin = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_Time.Name = "lbl_Time";
            this.lbl_Time.Size = new System.Drawing.Size(34, 15);
            this.lbl_Time.TabIndex = 3;
            this.lbl_Time.Text = "label1";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.Controls.Add(this.btn_Report, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_Settings, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_Help, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_Manage, 4, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 97);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 353);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // btn_Report
            // 
            this.btn_Report.BackColor = System.Drawing.Color.Wheat;
            this.btn_Report.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Report.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Report.Font = new System.Drawing.Font("A Iranian Sans", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_Report.Location = new System.Drawing.Point(405, 110);
            this.btn_Report.Margin = new System.Windows.Forms.Padding(5);
            this.btn_Report.Name = "btn_Report";
            this.btn_Report.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_Report.Size = new System.Drawing.Size(130, 131);
            this.btn_Report.TabIndex = 20;
            this.btn_Report.TabStop = false;
            this.btn_Report.Text = "گزارش انبار";
            this.btn_Report.UseVisualStyleBackColor = false;
            this.btn_Report.Click += new System.EventHandler(this.btn_Report_Click);
            // 
            // btn_Settings
            // 
            this.btn_Settings.BackColor = System.Drawing.Color.Wheat;
            this.btn_Settings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Settings.Font = new System.Drawing.Font("A Iranian Sans", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_Settings.Location = new System.Drawing.Point(265, 110);
            this.btn_Settings.Margin = new System.Windows.Forms.Padding(5);
            this.btn_Settings.Name = "btn_Settings";
            this.btn_Settings.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_Settings.Size = new System.Drawing.Size(130, 131);
            this.btn_Settings.TabIndex = 19;
            this.btn_Settings.TabStop = false;
            this.btn_Settings.Text = "تنظیمات";
            this.btn_Settings.UseVisualStyleBackColor = false;
            this.btn_Settings.Click += new System.EventHandler(this.btn_Settings_Click);
            // 
            // btn_Help
            // 
            this.btn_Help.BackColor = System.Drawing.Color.Wheat;
            this.btn_Help.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Help.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Help.Font = new System.Drawing.Font("A Iranian Sans", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_Help.Location = new System.Drawing.Point(125, 110);
            this.btn_Help.Margin = new System.Windows.Forms.Padding(5);
            this.btn_Help.Name = "btn_Help";
            this.btn_Help.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_Help.Size = new System.Drawing.Size(130, 131);
            this.btn_Help.TabIndex = 18;
            this.btn_Help.TabStop = false;
            this.btn_Help.Text = "راهنمایی و پشتیبانی";
            this.btn_Help.UseVisualStyleBackColor = false;
            this.btn_Help.Click += new System.EventHandler(this.btn_Help_Click);
            // 
            // btn_Manage
            // 
            this.btn_Manage.BackColor = System.Drawing.Color.Wheat;
            this.btn_Manage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Manage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Manage.Font = new System.Drawing.Font("A Iranian Sans", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btn_Manage.Location = new System.Drawing.Point(545, 110);
            this.btn_Manage.Margin = new System.Windows.Forms.Padding(5);
            this.btn_Manage.Name = "btn_Manage";
            this.btn_Manage.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_Manage.Size = new System.Drawing.Size(130, 131);
            this.btn_Manage.TabIndex = 10;
            this.btn_Manage.TabStop = false;
            this.btn_Manage.Text = "مدیریت انبار";
            this.btn_Manage.UseVisualStyleBackColor = false;
            this.btn_Manage.Click += new System.EventHandler(this.btn_Manage_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Name = "Frm_Main";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "صفحه اصلی";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Frm_Main_FormClosed);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btn_Manage;
        private System.Windows.Forms.Button btn_Report;
        private System.Windows.Forms.Button btn_Settings;
        private System.Windows.Forms.Button btn_Help;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lbl_WeekDay;
        private System.Windows.Forms.Label lbl_Time;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}