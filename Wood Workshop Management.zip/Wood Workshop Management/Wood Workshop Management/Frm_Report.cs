﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wood_Workshop_Management
{
    public partial class Frm_Report : Form
    {
        Frm_Settings objFrmSettings =new Frm_Settings();
        public Frm_Report()
        {
            InitializeComponent();
        }

        private void Frm_Report_FormClosing(object sender, FormClosingEventArgs e)
        {
            Frm_Main objMainFrm = new Frm_Main();
            objMainFrm.Show();
        }

        private void Frm_Report_Load(object sender, EventArgs e)
        {
            #region dataGridViewReset
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnCount = 5;

            dataGridView1.Columns[0].DataPropertyName = "Id";
            dataGridView1.Columns[0].HeaderText = "ID";
            dataGridView1.Columns[0].Name = "Id";
            dataGridView1.Columns[0].Width = 30;

            dataGridView1.Columns[1].DataPropertyName = "Name";
            dataGridView1.Columns[1].HeaderText = "نام محصول";
            dataGridView1.Columns[1].Name = "Name";
            dataGridView1.Columns[1].Width = 100;

            dataGridView1.Columns[2].DataPropertyName = "Count";
            dataGridView1.Columns[2].HeaderText = "تعداد";
            dataGridView1.Columns[2].Name = "Count";
            dataGridView1.Columns[2].Width = 50;

            dataGridView1.Columns[3].DataPropertyName = "PurchasePrice";
            dataGridView1.Columns[3].HeaderText = "قیمت خرید";
            dataGridView1.Columns[3].Name = "PurchasePrice";
            dataGridView1.Columns[3].Width = 90;

            dataGridView1.Columns[4].DataPropertyName = "SalePrice";
            dataGridView1.Columns[4].HeaderText = "قیمت فروش";
            dataGridView1.Columns[4].Name = "SalePrice";
            dataGridView1.Columns[4].Width = 90;
            #endregion

            objFrmSettings.refresh();
             
            lbl_Report.Text = "محصولات کمتر از " + objFrmSettings.reportLimit;

            SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Programming\\Projects\\Uni\\Wood Workshop Management\\Wood Workshop Management\\Database1.mdf\";Integrated Security=True");

            var query = "SELECT * FROM Tbl_Products WHERE IsLive=1 AND Count <= '"+objFrmSettings.reportLimit+"'";
            SqlCommand cmd = new SqlCommand(query, sc);
            DataTable dt = new DataTable();

            sc.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                dt.Load(reader);
            }
            sc.Close();
            dataGridView1.DataSource = dt;
        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
