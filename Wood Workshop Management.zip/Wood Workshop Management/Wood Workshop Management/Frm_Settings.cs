﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Wood_Workshop_Management
{
    public partial class Frm_Settings : Form
    {
        public int reportLimit;
        public Frm_Settings()
        {
            InitializeComponent();
        }

        private void Frm_Settings_FormClosing(object sender, FormClosingEventArgs e)
        {
            Frm_Main objMainFrm = new Frm_Main();
            objMainFrm.Show();
        }

       public void refresh()
        {
            try
            {
                var query = "SELECT ReportLimit FROM Tbl_Products";
                SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Programming\\Projects\\Uni\\Wood Workshop Management\\Wood Workshop Management\\Database1.mdf\";Integrated Security=True");

                sc.Open();

                SqlCommand sqlCommand = new SqlCommand(query, sc);
                var dr = sqlCommand.ExecuteReader();
                dr.Read();
                reportLimit = int.Parse(dr["ReportLimit"].ToString());

                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex.Message);
            }

        }

        private void Frm_Settings_Load(object sender, EventArgs e)
        {
            refresh();
            label1.Text = "حد گزارش فعلی : " + reportLimit;

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            int report = int.Parse(textBox1.Text);
            var query = "UPDATE Tbl_Products SET ReportLimit='" + report + "'";
            SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Programming\\Projects\\Uni\\Wood Workshop Management\\Wood Workshop Management\\Database1.mdf\";Integrated Security=True");

            try
            {
                sc.Open();
                SqlCommand sqlCommand = new SqlCommand(query, sc);
                int i = sqlCommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("با موفقیت بروزرسانی شد");
                    textBox1.Text = "";
                }
                else
                {
                    MessageBox.Show("انجام نشد! مجددا تلاش کنید");
                }
                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex.Message);
            }
            refresh();
            label1.Text = "حد گزارش فعلی : " + reportLimit;

        }
    }
}
