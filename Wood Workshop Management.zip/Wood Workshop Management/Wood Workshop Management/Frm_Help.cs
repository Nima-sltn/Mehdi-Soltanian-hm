﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wood_Workshop_Management
{
    public partial class Frm_Help : Form
    {
        public Frm_Help()
        {
            InitializeComponent();
        }

        private void Frm_Help_FormClosing(object sender, FormClosingEventArgs e)
        {
            Frm_Main objMainFrm = new Frm_Main();
            objMainFrm.Show();
        }

      
    }
}
