﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wood_Workshop_Management
{
    public partial class Frm_Main : Form
    {
        Timer timer;
        CultureInfo ci = new CultureInfo("fa-IR");
        DateTimeFormatInfo dtfa;
        Frm_Settings objFrmSettings=new Frm_Settings();
        public Frm_Main()
        {
            InitializeComponent();

             dtfa=ci.DateTimeFormat;
            dtfa.Calendar=new PersianCalendar();

            timer = new Timer();
            timer.Interval = 1000;

            timer.Tick += new EventHandler(timer1_Tick);
            timer.Start();

            lbl_WeekDay.Text = "امروز  "+ DateTime.Now.ToString("dddd",dtfa);
            lbl_Time.Text = DateTime.Now.ToString("hh:mm:ss", dtfa);
            //lbl_Date.Text = DateTime.Now.ToString(dtfa);
        }
        
        private void btn_Manage_Click(object sender, EventArgs e)
        {
            this.Hide();
            Frm_Management objFrmManage = new Frm_Management();
            objFrmManage.Show();
        }

        private void btn_Report_Click(object sender, EventArgs e)
        {
            this.Hide();
            Frm_Report objFrmReport = new Frm_Report();
            objFrmReport.Show();
        }

        private void btn_Settings_Click(object sender, EventArgs e)
        {
            this.Hide();
            Frm_Settings objFrmSetting = new Frm_Settings();
            objFrmSetting.Show();
        }

        private void btn_Help_Click(object sender, EventArgs e)
        {
            this.Hide();
            Frm_Help objFrmHelp = new Frm_Help();
            objFrmHelp.Show();
        }

        private void Frm_Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_Time.Text = DateTime.Now.ToString("hh:mm:ss", dtfa);
        }

       
        
    }
}
