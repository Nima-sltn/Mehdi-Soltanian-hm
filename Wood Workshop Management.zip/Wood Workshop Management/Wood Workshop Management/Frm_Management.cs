﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System.Xml.Linq;

namespace Wood_Workshop_Management
{
    public partial class Frm_Management : Form
    {
        int PrdGrid_SQLId;
        public Frm_Management()
        {
            InitializeComponent();
            
        }

        void refresh()
        {
            SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Programming\\Projects\\Uni\\Wood Workshop Management\\Wood Workshop Management\\Database1.mdf\";Integrated Security=True");

            var query = "SELECT * FROM Tbl_Products WHERE IsLive=1";
            SqlCommand cmd = new SqlCommand(query,sc);
            DataTable dt = new DataTable();

            sc.Open();
            using(SqlDataReader reader = cmd.ExecuteReader())
            {
                dt.Load(reader);
            }
            sc.Close();
            dataGridView1.DataSource = dt;
        }

        private void Frm_Management_Load(object sender, EventArgs e)
        {
            #region dataGridViewReset
            dataGridView1.AutoGenerateColumns = false;
            //dataGridView1.ColumnCount = 5;

            dataGridView1.Columns[0].DataPropertyName = "Id";
            dataGridView1.Columns[0].HeaderText = "ID";
            dataGridView1.Columns[0].Name = "Id";
            dataGridView1.Columns[0].Width = 30;

            dataGridView1.Columns[1].DataPropertyName = "Name";
            dataGridView1.Columns[1].HeaderText = "نام محصول";
            dataGridView1.Columns[1].Name = "Name";
            dataGridView1.Columns[1].Width = 100;

            dataGridView1.Columns[2].DataPropertyName = "Count";
            dataGridView1.Columns[2].HeaderText = "تعداد";
            dataGridView1.Columns[2].Name = "Count";
            dataGridView1.Columns[2].Width = 50;

            dataGridView1.Columns[3].DataPropertyName = "PurchasePrice";
            dataGridView1.Columns[3].HeaderText = "قیمت خرید";
            dataGridView1.Columns[3].Name = "PurchasePrice";
            dataGridView1.Columns[3].Width = 90;

            dataGridView1.Columns[4].DataPropertyName = "SalePrice";
            dataGridView1.Columns[4].HeaderText = "قیمت فروش";
            dataGridView1.Columns[4].Name = "SalePrice";
            dataGridView1.Columns[4].Width = 90;
            #endregion


            refresh();
            btn_Delete.Enabled = false;

            // TODO: This line of code loads data into the 'database1DataSet1.Tbl_Products' table. You can move, or remove it, as needed.
            this.tbl_ProductsTableAdapter.Fill(this.database1DataSet1.Tbl_Products);

        }

        private void Frm_Management_FormClosing(object sender, FormClosingEventArgs e)
        {
            Frm_Main objMainFrm = new Frm_Main();
            objMainFrm.Show();
        }
        
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            PrdGrid_SQLId = (int)dataGridView1.Rows[e.RowIndex].Cells["Id"].Value;
            try
            {
                var query = "SELECT * FROM Tbl_Products WHERE Id='"+PrdGrid_SQLId+"'";
                SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Programming\\Projects\\Uni\\Wood Workshop Management\\Wood Workshop Management\\Database1.mdf\";Integrated Security=True");
                //dataGridView1.DataSource=query;
                sc.Open();

                SqlCommand sqlCommand = new SqlCommand(query, sc);
                var dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    txt_Name.Text = dr["Name"].ToString();
                    txt_Count.Text = dr["Count"].ToString();
                    txt_PurchasePrice.Text = dr["PurchasePrice"].ToString();
                    txt_SalePrice.Text = dr["SalePrice"].ToString();
                }
                groupBox1.Text = "ویرایش محصول";
                btn_Submit.Text = "ویرایش";

                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex.Message);
            }
            btn_Delete.Enabled = true;
        }
       
        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dataGridView1.ClearSelection();
            txt_Name.Text = txt_Count.Text = txt_PurchasePrice.Text = txt_SalePrice.Text = "";
            btn_Submit.Text = "ثبت";
            groupBox1.Text = "ثبت محصول";
        }
       
        private void btn_Submit_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txt_Name.Text;
                string pPrice = txt_PurchasePrice.Text;
                string sPrice = txt_SalePrice.Text;
                string count = txt_Count.Text;
                var insertQuery = "INSERT INTO Tbl_Products (Name,PurchasePrice,SalePrice,Count)" +
                    "VALUES (N'" + name + "','" + pPrice + "','" + sPrice + "','" + count + "')";

                var updateQuery = "UPDATE Tbl_Products SET Name=N'" + name + "',PurchasePrice='" + pPrice + "',SalePrice='" + sPrice + "',Count='" + count + "' WHERE Id='"+PrdGrid_SQLId+"'";

                SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Programming\\Projects\\Uni\\Wood Workshop Management\\Wood Workshop Management\\Database1.mdf\";Integrated Security=True");

                sc.Open();

                if (btn_Submit.Text == "ثبت")
                {
                    SqlCommand sqlCommand = new SqlCommand(insertQuery, sc);
                    
                    if (txt_Name.Text == string.Empty || txt_Count.Text == string.Empty || txt_PurchasePrice.Text == string.Empty || txt_SalePrice.Text == string.Empty)
                    {
                        MessageBox.Show("اطلاعات را کامل وارد کنید");
                    }
                    else
                    {
                        int i = sqlCommand.ExecuteNonQuery();
                        if (i > 0)
                        {
                            MessageBox.Show("با موفقیت ثبت شد");
                            refresh();
                            txt_Name.Text = txt_Count.Text = txt_PurchasePrice.Text = txt_SalePrice.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("ثبت نشد! مجددا تلاش کنید");
                        }
                    }
                }
                else
                {
                    SqlCommand sqlCommand = new SqlCommand(updateQuery, sc);
                    int i = sqlCommand.ExecuteNonQuery();
                    if (i > 0)
                    {
                        MessageBox.Show("با موفقیت بروزرسانی شد");
                        refresh();
                        txt_Name.Text = txt_Count.Text = txt_PurchasePrice.Text = txt_SalePrice.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("بروزرسانی نشد! مجددا تلاش کنید");
                    }
                }

               

                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex.Message);
            }
        }
       
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            var query = "UPDATE Tbl_Products SET IsLive=0 WHERE Id='" + PrdGrid_SQLId + "'";
            SqlConnection sc = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Programming\\Projects\\Uni\\Wood Workshop Management\\Wood Workshop Management\\Database1.mdf\";Integrated Security=True");

            try
            {
                sc.Open();
                SqlCommand sqlCommand = new SqlCommand(query, sc);
                int i = sqlCommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("با موفقیت حذف شد");
                    refresh();
                    txt_Name.Text = txt_Count.Text = txt_PurchasePrice.Text = txt_SalePrice.Text = "";
                }
                else
                {
                    MessageBox.Show("حذف نشد! مجددا تلاش کنید");
                }
                sc.Close();
            }catch(Exception ex)
            {
                MessageBox.Show("Error! " + ex.Message);
            }

        }
    }
}
